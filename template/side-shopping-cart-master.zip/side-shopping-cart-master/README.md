Side Shopping Cart
=========

An animated side cart to let users jump in and out from the list of products they want to buy, without having to refresh the page or fire a popup.

[Article on CodyHouse](http://codyhouse.co/gem/side-shopping-cart/)

[Demo](http://codyhouse.co/demo/side-cart/)
 
[Terms](http://codyhouse.co/terms/)


[© CodyHouse 2014](http://codyhouse.co/)
